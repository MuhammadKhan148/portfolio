import WorkingPortfolio from "../portfolio-working"

export default function Page() {
  return <WorkingPortfolio />
}
